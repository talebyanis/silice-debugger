
Examples taken from Silice/projects
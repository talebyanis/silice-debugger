# WolfFPGA

*The wolfenstein 3D render loop*

## How to build

This projet requires a [VGA DAC](../DIYVGA.md). It was tested on a 
MojoV3 board, de10nano, ulx3s, and can be simulated with Icarus/Verilator

## Textures

The four textures in wolf.tga are damaged versions of the original ones 
(for copyright reasons), and the result is quite horrible.

Simply replace by textures from your copy of the game for best results!
